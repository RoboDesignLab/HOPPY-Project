#ifndef __F28379D_EPWM_H__
#define __F28379D_EPWM_H__

void init_EPWM1A_GPIO(void);
void init_EPWM1A(void);
void set_EPWM1A(float u);

void init_EPWM1A_GPIO_VNH5019(void);
void init_EPWM1A_VNH5019(void);
void set_EPWM1A_VNH5019(float u);

void init_EPWM1B_GPIO(void);
void init_EPWM1B(void);
void set_EPWM1B(float u);

void init_EPWM1B_GPIO_VNH5019(void);
void init_EPWM1B_VNH5019(void);
void set_EPWM1B_VNH5019(float u);

void init_EPWM2A_GPIO(void);
void init_EPWM2A(void);
void set_EPWM2A(float u);

void init_EPWM2B_GPIO(void);
void init_EPWM2B(void);
void set_EPWM2B(float u);

void init_EPWM3A_GPIO(void);
void init_EPWM3A(void);
void set_EPWM3A(float u);

void init_EPWM3B_GPIO(void);
void init_EPWM3B(void);
void set_EPWM3B(float u);

#endif /* __F28379DEPWM_H__ */


