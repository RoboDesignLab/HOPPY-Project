#ifndef LS7366R_H__
#define LS7366R_H__

#include <F2837xD_device.h>

// Function prototypes
void init_SPIB_LS7366R(void);
void SPIB_RXint_LS7366R(void);
void start_SPIB_LS7366R(void);

#endif 
