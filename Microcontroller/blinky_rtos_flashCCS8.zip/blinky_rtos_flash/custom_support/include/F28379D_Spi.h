#ifndef F28379D_SPI_H__
#define F28379D_SPI_H__

#include <F2837xD_device.h>

// Function prototypes
void init_SPIB_GPIO(void);

#endif 
