/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-H28
 */

#ifndef xconfig_rtos_cpu1__
#define xconfig_rtos_cpu1__



#endif /* xconfig_rtos_cpu1__ */ 
