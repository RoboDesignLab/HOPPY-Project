/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-H28
 */

#ifndef xconfig_cpu01_rtos__
#define xconfig_cpu01_rtos__



#endif /* xconfig_cpu01_rtos__ */ 
